import React from 'react'
import {useNavigate} from "react-router-dom"
function privateRoute({children}) {
    const navigate = useNavigate()

  return (
    <div>
      if(token){
        {children}

      }else{
        navigate("/admin")
      }

    </div>
  )
}

export default privateRoute
