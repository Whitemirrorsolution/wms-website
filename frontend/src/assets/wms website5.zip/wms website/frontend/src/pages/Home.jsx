import React from 'react'
import ApplyModal from '../components/ApplyModal'
import JobListings from '../components/JobListings'

function Home() {
  return (
    <div>
      <JobListings/>
    </div>
  )
}

export default Home
