
import { Link, useNavigate } from "react-router-dom";
import JobList from "../components/JobListings";
import JobPostForm from "./JobPostForm";



const AdminDashboard = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('adminAuthenticated');
    navigate('/');
  };

  return (
    <div className="w-screen bg-gradient-to-br from-blue-50 to-blue-100 p-4 sm:p-8 flex flex-col items-center min-h-screen">
      <div className="w-full max-w-5xl pt-16">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-4xl sm:text-5xl font-extrabold text-blue-800 tracking-tight drop-shadow-lg">
            <span className="bg-gradient-to-r from-blue-500 via-blue-400 to-blue-600 bg-clip-text text-transparent">Admin Dashboard</span>
          </h1>
          <button
            onClick={handleLogout}
            className="ml-4 px-5 py-2 bg-gradient-to-r from-blue-600 to-cyan-500 text-white font-semibold rounded-lg shadow hover:from-blue-700 hover:to-cyan-600 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2"
          >
            Logout
          </button>
        </div>

        <div className="w-full flex flex-col sm:flex-row gap-4 justify-center mb-8">
          <Link
            to="/admin/application"
            className="flex-1 text-center bg-gradient-to-r from-blue-600 to-blue-500 text-white font-semibold rounded-lg shadow hover:from-blue-700 hover:to-blue-600 transition-colors duration-200 px-5 py-3 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2"
          >
            View Applications
          </Link>
          <Link
            to="/admin/contact"
            className="flex-1 text-center bg-gradient-to-r from-green-600 to-green-500 text-white font-semibold rounded-lg shadow hover:from-green-700 hover:to-green-600 transition-colors duration-200 px-5 py-3 focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-offset-2"
          >
            View Contact Messages
          </Link>
        </div>

        <div className="mb-8">
          <JobPostForm />
        </div>
        <div>
          <JobList />
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
