import React from 'react'


import { useState } from "react";
import {useNavigate} from "react-router-dom"
import { FiUserCheck } from 'react-icons/fi';

function AdminLogin() {
   const navigate = useNavigate();
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const [error, setError] = useState('');

  const adminCredentials = {
    email: 'ram@gmail.com',
    password: '123456'
  };

  const handleSignIn = (e) => {
    e.preventDefault();
    if (
      credentials.email === adminCredentials.email &&
      credentials.password === adminCredentials.password
    ) {
      localStorage.setItem('adminAuthenticated', true);
      navigate('/admin/dashboard');
    } else {
      setError('Invalid admin email or password.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-cyan-100 to-blue-200 px-4 sm:px-8 py-10">
      <div className="w-full max-w-md xl:max-w-lg bg-white/80 backdrop-blur-lg border border-blue-100 p-8 sm:p-12 rounded-3xl shadow-2xl transition-all">
        <div className="flex justify-center mb-4">
          <FiUserCheck className="text-5xl md:text-6xl text-blue-600 drop-shadow" />
        </div>
        <h2 className="text-3xl sm:text-4xl font-extrabold text-center bg-gradient-to-r from-blue-700 via-cyan-600 to-blue-400 bg-clip-text text-transparent mb-6 tracking-tight drop-shadow">
          Admin Sign In
        </h2>
        <form onSubmit={handleSignIn} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-blue-800 mb-1">Email</label>
            <input
              type="email"
              value={credentials.email}
              onChange={(e) => setCredentials({ ...credentials, email: e.target.value })}
              required
              className="w-full px-4 py-3 bg-white/90 border border-blue-200 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400 font-medium text-gray-900 placeholder-gray-400 transition"
              placeholder="Enter admin email"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-blue-800 mb-1">Password</label>
            <input
              type="password"
              value={credentials.password}
              onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
              required
              className="w-full px-4 py-3 bg-white/90 border border-blue-200 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-400 font-medium text-gray-900 placeholder-gray-400 transition"
              placeholder="Enter password"
            />
          </div>
          {error && <p className="text-sm text-red-500 -mt-2 text-center font-semibold">{error}</p>}
          <button
            type="submit"
            className="w-full bg-gradient-to-r from-blue-700 via-cyan-600 to-blue-800 hover:from-blue-800 hover:to-cyan-700 text-white font-bold py-3 rounded-lg shadow-md hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
          >
            Sign In as Admin
          </button>
        </form>
      </div>
    </div>
  );
}

export default AdminLogin

