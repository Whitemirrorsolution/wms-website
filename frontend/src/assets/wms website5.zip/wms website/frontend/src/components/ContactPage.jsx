import { useState } from "react";
import axios from "axios";
import { motion } from 'framer-motion';
const ContactPage = () => {
  const [form, setForm] = useState({ fullName: "", email: "", number: "", subject: "", message: "" });
  const [success, setSuccess] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);

  const fadeUp = {
    hidden: { opacity: 0, y: 50 },
    visible: (i = 0) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.2, duration: 0.6, ease: "easeOut" },
    }),
  };

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post("http://localhost:8000/api/contact", form);
      setSuccess("Message sent successfully!");
      setShowSuccess(true);
      setForm({ fullName: "", email: "", number: "", subject: "", message: "" });
      setTimeout(() => setShowSuccess(false), 3500);
    } catch (err) {
      setSuccess("");
      setShowSuccess(false);
      console.error(err);
    }
  };
  return (
    <section
      id="contact"
      className="w-full min-h-screen bg-gradient-to-br from-white via-sky-100 to-cyan-50 py-8 sm:py-10 md:py-14 overflow-hidden relative"
      style={{ fontFamily: 'Inter, sans-serif' }}
    >
      {/* Success Toast */}
      {showSuccess && (
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -30 }}
          className="fixed top-4 left-1/2 z-50 -translate-x-1/2 bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-4 py-2 rounded-lg shadow-lg font-semibold text-xs xs:text-sm sm:text-base flex items-center gap-2"
        >
          <svg width="18" height="18" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="12" fill="#fff" fillOpacity=".15"/><path d="M7 13l3 3 7-7" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
          {success}
        </motion.div>
      )}

      {/* Section Header */}
      <motion.div
        className="text-center mb-8 sm:mb-12 md:mb-16 px-2 sm:px-4"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={fadeUp}
      >
        <h2 className="text-2xl xs:text-3xl sm:text-4xl md:text-5xl font-extrabold text-gray-900 mb-2 sm:mb-4 tracking-tight drop-shadow-lg">
          Contact
        </h2>
        <p className="text-xs xs:text-sm sm:text-base md:text-lg text-gray-700 max-w-xl sm:max-w-3xl mx-auto">
          Ready to transform your business? Get in touch with our experts and let's discuss your next project.
        </p>
      </motion.div>

      {/* Contact Form and Info Grid */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-10 lg:gap-12 px-2 sm:px-4 lg:px-8">
        {/* Contact Form */}
        <motion.div
          className="backdrop-blur-lg bg-white/70 border border-blue-100 rounded-xl sm:rounded-2xl shadow-2xl p-4 xs:p-6 sm:p-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          custom={1}
        >
          <h3 className="text-lg xs:text-xl sm:text-2xl font-bold text-blue-900 mb-2 sm:mb-4">Let's Start a Conversation</h3>
          <p className="text-xs xs:text-sm sm:text-base text-gray-600 mb-3 sm:mb-6">Fill out the form below and we’ll get back to you within 24 hours.</p>
          <form className="space-y-3 xs:space-y-4 sm:space-y-5" onSubmit={handleSubmit}>
            <div className="w-full">
              <input
                type="text"
                name="fullName"
                placeholder="Enter Your Name *"
                className="w-full p-2 xs:p-2.5 sm:p-3 bg-white/80 border border-blue-200 shadow-sm rounded-md sm:rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 font-medium text-gray-900 placeholder-gray-400 transition text-xs xs:text-sm sm:text-base"
                value={form.fullName}
                onChange={handleChange}
                required
              />
            </div>
            <input
              type="email"
              name="email"
              placeholder="Email Address *"
              className="w-full p-2 xs:p-2.5 sm:p-3 bg-white/80 border border-blue-200 shadow-sm rounded-md sm:rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 font-medium text-gray-900 placeholder-gray-400 transition text-xs xs:text-sm sm:text-base"
              value={form.email}
              onChange={handleChange}
              required
            />
            <input
              type="tel"
              name="number"
              placeholder="Phone Number"
              className="w-full p-2 xs:p-2.5 sm:p-3 bg-white/80 border border-blue-200 shadow-sm rounded-md sm:rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 font-medium text-gray-900 placeholder-gray-400 transition text-xs xs:text-sm sm:text-base"
              value={form.number}
              onChange={handleChange}
            />
            <select
              name="subject"
              className="w-full p-2 xs:p-2.5 sm:p-3 bg-white/80 border border-blue-200 shadow-sm rounded-md sm:rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400 font-medium text-gray-900 transition text-xs xs:text-sm sm:text-base"
              value={form.subject}
              onChange={handleChange}
              required
            >
              <option value="">Select a service *</option>
              <option>Web Development</option>
              <option>App Development</option>
              <option>Digital Marketing</option>
              <option>IT Consulting</option>
            </select>
            <textarea
              rows="4"
              name="message"
              placeholder="Message *"
              className="w-full p-2 xs:p-2.5 sm:p-3 bg-white/80 border border-blue-200 shadow-sm rounded-md sm:rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-400 font-medium text-gray-900 placeholder-gray-400 transition text-xs xs:text-sm sm:text-base"
              value={form.message}
              onChange={handleChange}
              required
            ></textarea>
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-700 via-cyan-600 to-blue-800 hover:from-blue-800 hover:to-cyan-700 text-white font-bold py-2 xs:py-2.5 sm:py-3 rounded-md sm:rounded-lg shadow-md hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 text-xs xs:text-sm sm:text-base"
            >
              Send Message
            </button>
          </form>
        </motion.div>

        {/* Contact Info Cards */}
        <motion.div
          className="space-y-4 sm:space-y-6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          custom={2}
        >
          {/* Office Card with Background Image */}
          <motion.div
            className="relative bg-cover bg-center rounded-lg sm:rounded-xl shadow-lg h-28 xs:h-32 sm:h-40 overflow-hidden"
            style={{
              backgroundImage:
                "url('https://media.istockphoto.com/id/2156471449/photo/business-smart-logistics-concept-global-business-connection-technology-interface-global.webp?a=1&b=1&s=612x612&w=0&k=20&c=vNGqb3f22hcElD9mD4l9t_ZtmbYEdDnosXckL4VkjJU=')",
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-900/60 via-cyan-700/40 to-blue-700/60 rounded-lg sm:rounded-xl"></div>
            <div className="absolute bottom-2 left-2 sm:bottom-4 sm:left-4 z-10">
              <h4 className="text-xs xs:text-sm sm:text-lg font-bold text-white drop-shadow">Our Office</h4>
              <p className="text-[10px] xs:text-xs sm:text-sm text-gray-200">Modern workspace in Indore</p>
            </div>
          </motion.div>

          {/* Info Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-5">
            {[
              {
                title: "Address",
                icon: "📍",
                content: "669, A-2, SCH No.136\nIndore-452010\nMadhya Pradesh, India",
              },
              {
                title: "Phone",
                icon: "📞",
                content: "+91 79874-35108\nMon - Fri, 9:00 AM - 6:00 PM",
              },
              {
                title: "Email",
                icon: "📧",
                content: "info@whitemirror.com\nWe’ll respond within 24 hours",
              },
              {
                title: "Support",
                icon: "💬",
                content: "24/7 Technical Support\nAlways here to help",
              },
            ].map((item, i) => (
              <motion.div
                key={item.title}
                variants={fadeUp}
                custom={i + 3}
                whileHover={{ scale: 1.06 }}
                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                className="backdrop-blur-md bg-white/70 border border-blue-100 rounded-lg p-2 xs:p-3 sm:p-4 shadow-lg cursor-pointer hover:shadow-xl hover:bg-white/90 transition"
              >
                <p className="text-xs xs:text-sm sm:text-base text-blue-700 font-semibold flex items-center gap-2">
                  <span className="text-base xs:text-lg sm:text-xl">{item.icon}</span> {item.title}
                </p>
                <p className="text-[10px] xs:text-xs sm:text-sm text-gray-700 mt-0.5 sm:mt-1 whitespace-pre-line">{item.content}</p>
              </motion.div>
            ))}
          </div>

          {/* Expert Team Card */}
          <motion.div
            className="relative bg-cover bg-center rounded-lg sm:rounded-xl shadow-lg h-28 xs:h-32 sm:h-40 overflow-hidden"
            style={{
              backgroundImage:
                "url('https://images.unsplash.com/photo-1551135049-8a33b5883817?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTZ8fGV4cGVydCUyMHRlYW0lMjBpbWFnZXxlbnwwfHwwfHx8MA%3D%3D')",
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-900/60 via-cyan-700/40 to-blue-700/60 rounded-lg sm:rounded-xl"></div>
            <div className="absolute bottom-2 left-2 sm:bottom-4 sm:left-4 z-10">
              <h4 className="text-xs xs:text-sm sm:text-lg font-bold text-white drop-shadow">Expert Team</h4>
              <p className="text-[10px] xs:text-xs sm:text-sm text-gray-200">ready to bring your vision to life</p>
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* CTA Box */}
      <motion.div
        className="max-w-6xl mx-2 sm:mx-4 md:mx-auto mt-4 sm:mt-8 md:mt-12 bg-gradient-to-r from-blue-700 via-cyan-600 to-blue-800 text-white text-center py-4 xs:py-5 sm:py-7 md:py-10 px-2 xs:px-3 sm:px-4 md:px-6 rounded-lg sm:rounded-xl shadow-2xl border border-blue-200"
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        variants={fadeUp}
        custom={7}
      >
        <h3 className="text-base xs:text-lg sm:text-xl md:text-2xl font-extrabold mb-1 sm:mb-2 drop-shadow">Need Immediate Assistance?</h3>
        <p className="text-[10px] xs:text-xs sm:text-sm md:text-base mb-2 sm:mb-4">Call us directly or schedule a free consultation with our experts.</p>
        <div className="flex flex-col sm:flex-row justify-center gap-1 xs:gap-2 sm:gap-3">
          <a
            href="tel:+917987435108"
            className="mx-8 sm:mx-0 bg-white text-blue-800 font-bold px-3 xs:px-4 sm:px-5 md:px-7 py-1.5 xs:py-2 sm:py-2.5 md:py-3 rounded-md sm:rounded-lg shadow-md hover:shadow-xl hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 text-xs xs:text-sm sm:text-base"
            style={{ color: "#0957bd" }}
          >
            Call Now: +91 79874-35108
          </a>
          <button
            className="mx-8 sm:mx-0 text-white border-2 border-white font-bold px-3 xs:px-4 sm:px-5 md:px-7 py-1.5 xs:py-2 sm:py-2.5 md:py-3 rounded-md sm:rounded-lg bg-transparent hover:bg-white hover:text-blue-800 hover:shadow-lg hover:scale-105 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400 text-xs xs:text-sm sm:text-base"
          >
            Schedule Consultation
          </button>
        </div>
      </motion.div>
    </section>
  );
};

export default ContactPage;


