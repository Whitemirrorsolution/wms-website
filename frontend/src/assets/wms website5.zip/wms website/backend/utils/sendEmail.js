import nodemailer from "nodemailer";
import fs from "fs"

export const sendApplicationEmail = async (application) => {
  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER, // e.g., yourname@gmail.com
        pass: process.env.EMAIL_PASS, // App password (not Gmail login password)
      },
    });

    const message = `
New Job Application Received:

🧑 Full Name: ${application.fullName}
📧 Email: ${application.email}
📞 Phone: ${application.phone}
⚥ Gender: ${application.gender}
🎂 Date of Birth: ${application.dateOfBirth || application.dob}
🎓 Qualification: ${application.qualification}
💼 Applied For: ${application.appliedJobTitle}
📝 Cover Letter: ${application.coverLetter || "N/A"}
`;

    await transporter.sendMail({
      from: `"Career Page" <${process.env.EMAIL_USER}>`,
      to: process.env.EMAIL_TO, // Admin email (you)
      subject: `New Application - ${application.appliedJobTitle}`,
      text: message,
      attachments: [
        {
          filename: application.resumePath?.split("-").pop() || "resume.pdf",
          path: application.resumePath,
        },
      ],
    });
      fs.unlink(application.resumePath, (err) => {
          if (err) console.error('Error removing file:', err);
        });

    console.log("✅ Email sent successfully");
  } catch (error) {
    console.error("❌ Error sending email:", error);
     fs.unlink(application.resumePath, (err) => {
          if (err) console.error('Error removing file:', err);
        });
    throw new Error("Email sending failed");
  }
};
