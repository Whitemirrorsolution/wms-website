import Contact from "../models/contact.model.js";

export const createContact = async (req, res) => {
  try {
    const { fullName, email, number, subject, message } = req.body;
    const newMessage = await Contact.create({ fullName, email, number, subject, message });
    console.log(newMessage)
    res.status(201).json({ message: "Message sent successfully", newMessage });
  } catch (error) {
    res.status(500).json({ message: "Something went wrong" });
  }
};


export const getAllContacts = async (req, res) => {
  try {
    const messages = await Contact.find().sort({ createdAt: -1 });
    
    res.status(200).json({ messages });
  } catch (err) {
    res.status(500).json({ message: "Error fetching contact messages" });
  }
};
