
import Admin from "../models/admin.model.js";
import bcrypt from "bcrypt"


export const signup = async(req, res)=>{
  try {
   let{name, email, password} = req.body
    const existEmail = await Admin.findOne({email})
    if(existEmail){
      return res.status(400).json({ message: "Email already exists!"})
     }
     if(password.length<6){
            return res.status(400).json({message: "password must be at least 6 characters!"})
     }
    const hashedPassword = await bcrypt.hash(password, 10)
    const admin = await Admin.create({
        name,
        email,
        password:hashedPassword
    });

    const token = genToken(admin._id)
    res.cookie("token", token, {
        httpOnly:true,
        maxAge: 7 * 24 * 60 * 60 * 1000, 
        sameSite: "strict",
        secure: process.env.NODE_ENV === "production"

    })
    return res.status(201).json(admin)
  
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "Signup error" });
    
  }
    
}

export const login = async(req, res)=>{
    try {
    let {email, password} = req.body
    const admin = await Admin.findOne({email})
     if(!admin){
        return res.status(400).json({message: "admin does not exist!"})
        }
        const isMatch = await bcrypt.compare(password, admin.password);
        if(!isMatch){
            return res.status(400).json({message: "Incorrect Password!"})
        }
         const token = genToken(admin._id)
     res.cookie("token", token, {
        httpOnly:true,
        maxAge: 7 * 24 * 60 * 60 * 1000, 
        sameSite: "strict",
        secure: process.env.NODE_ENV === "production"

    })
      return res.status(201).json(admin)
    } catch (error) {
    console.error(error);
    return res.status(500).json({ message: "login error" });
        
    }
}

export const logOut = async (req, res)=>{
    try {
        res.clearCookie("token");
        return res.status(200).json({message: "Logout Successfully"})
    } catch (error) {
        console.log(error)
        return res.status(500).json({message: "logout error"})
    }
}


