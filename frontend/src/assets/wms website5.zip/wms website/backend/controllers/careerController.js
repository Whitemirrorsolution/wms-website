import nodemailer from "nodemailer"
import fs from "fs"




export const ApplyUserJob = async (req, res)=>{
  
  try {
    let { selectedJobTitle,fullName, email, phone, gender, dateOfBirth, qualification, coverLetter } = req.body

    if(!fullName || !email){
      return res.status(400).json({message:"input does not exist!"})
    }
    const resumePath = req.file.path;
    const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: process.env.EMAIL_TO,
      subject: `New Application for ${selectedJobTitle}`,
      text: `
        New Job Application Received:
        
        Full Name: ${fullName}
        Email: ${email}
        
        Phone: ${phone}
        Gender: ${gender}
        Date of Birth: ${dateOfBirth}
        Qualification: ${qualification}
        Cover Letter: ${coverLetter || 'N/A'}
        `
      ,
      attachments: [
        {
          filename: path.basename(resumePath),
          path: resumePath
        }
      ]
    };

    await transporter.sendMail(mailOptions);
    
   
    fs.unlink(resumePath, (err) => {
      if (err) console.error('Error removing file:', err);
    });

  } catch (error) {
    console.log("error"+error);
        fs.unlink(resumePath, (err) => {
      if (err) console.error('Error removing file:', err);
    });
    
  }
}

